//
///*
// * File:   main.c
// * Author: lavanya N U

#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
//#include "isr.h"
#include "timer0.h"


uint16_t speed=SPEED_MSG_ID;
uint16_t gear_id=GEAR_MSG_ID;
uint16_t rpm_id=RPM_MSG_ID;
uint16_t ind_id=INDICATOR_MSG_ID;

uint8_t data[8];
uint8_t size=5;

static void init_leds() {
//    TRISB = 0x08; // Set RB2 as output, RB3 as input, remaining as output
//    PORTB = 0x00;
}

static void init_config(void) {
    // Initialize CLCD and CANBUS
    init_clcd();
    init_can();
    init_leds();

    // Enable Interrupts
//    PEIE = 1;
//    GIE = 1;
//    init_timer0();
}

void main(void) {
    // Initialize peripherals
    init_config();
    
    clcd_print("GEAR",LINE1(0));
    clcd_print("SPD",LINE1(5));
    clcd_print("RPM",LINE1(9));
    clcd_print("IND",LINE1(13));
    /* ECU1 main loop */
    while (1) {
//        clcd_print("SPD",LINE1(0));
//    clcd_print("GEAR",LINE1(4));
//    clcd_print("RPM",LINE1(9));
//    clcd_print("IND",LINE1(13));

        // Read CAN Bus data and handle it
        process_canbus_data();
    }

    return;
}
