#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"

extern uint8_t data[8];
extern uint8_t size;
static uint16_t msg_id;
volatile unsigned char led_state = LED_OFF, status = e_ind_off;


void handle_speed_data(uint8_t *data, uint8_t len)
{
    
    clcd_print(data,LINE2(5));
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    clcd_print(data,LINE2(1));
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    clcd_print(data,LINE2(8));
}

//void handle_engine_temp_data(uint8_t *data, uint8_t len) 
//{
//    //Implement the temperature function
//}

void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    if(data[0]=='1')
    {
        clcd_print("<--",LINE2(13));
    }
    else if(data[0]=='2')
    {
         clcd_print("OFF",LINE2(13));
    }
    else if(data[0]=='3')
    {
         clcd_print("-->",LINE2(13));
    }
    
    
//    static unsigned int delay=10000;
//    
//     if(data[0]=='1')
//     {
//         clcd_print("<-",LINE2(13));
//         if(delay>5000)
//         {
//            delay--; 
//            clcd_print("<-",LINE2(13));
//            LEFT_IND_ON();
//         }
//         else
//         {
//             clcd_print(" ",LINE2(13));
//             LEFT_IND_OFF();
//         }
//         if(delay==0)
//         {
//             delay=10000;
//         }
//             
//       }
//     else if(data[0]=='3')
//     {
//          clcd_print("->",LINE2(13));
//          if(delay>5000)
//         {
//            delay--; 
//            clcd_print("->",LINE2(13));
//            RIGHT_IND_ON();
//         }
//         else
//         {
//             clcd_print(" ",LINE2(13));
//             RIGHT_IND_OFF();
//         }
//         if(delay==0)
//         {
//             delay=10000;
//         }
//         else if(data[0]=='2')
//         {
//             status=e_ind_off;
//             clcd_print("OFF",LINE2(13));
//             LEFT_IND_OFF();
//             RIGHT_IND_OFF();
//         }
//     
//    
//      }0
}

void process_canbus_data() 
{   
    
   static unsigned char flag;
//    uint16_t msg_id;
//    uint8_t data;
//    uint8_t size;
    can_receive(&msg_id,data,&size);
//    data[size]='\0';
    
    
//    if(msg_id==GEAR_MSG_ID)
//     handle_gear_data(data,size);
//    else if(msg_id==SPEED_MSG_ID)
//     handle_speed_data(data,size);
//    else if(msg_id==RPM_MSG_ID) 
//     handle_rpm_data(data,size);
//    else if(msg_id==INDICATOR_MSG_ID)
//     handle_indicator_data(data,size);    
     
    switch(msg_id)
    {
        case SPEED_MSG_ID:
        {
            flag=1;
            break;
            
        }
        case GEAR_MSG_ID:
        {
            flag=2;
            break;
        }
        case RPM_MSG_ID:
        {
            flag=3;
            break;
        }
        case INDICATOR_MSG_ID:
        {
            flag=4;
            break;
        }
        
    }
    if(flag==1)
    {
        handle_speed_data(data,size);
    }
    else if(flag==2)
    {
        handle_gear_data(data,size);
    }
    else if(flag==3)
    {
        handle_rpm_data(data,size);
    }
    else if(flag==4)
    {
        handle_indicator_data(data,size);
    }
    
        
}