#include<xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
//#include "uart.h"
#include "digital_keypad.h"
#include "clcd.h"
#include<stdio.h>

unsigned int adc_reg_value;
unsigned int rpm;

extern uint8_t rpm_data[5];
extern uint8_t ind[3];

volatile unsigned char led_state;
unsigned int delay1=10000;
unsigned int delay2=10000;
unsigned char str[1];

uint16_t get_rpm()
{
   
     adc_reg_value=read_adc(RPM_ADC_CHANNEL);
     rpm=(adc_reg_value*6000.0)/1023.0;
     
     sprintf(str,"%d",rpm);
//     clcd_print(str,LINE1(5));
     
     rpm_data[0]=(rpm/1000)+'0';
     rpm_data[1]=((rpm/100)%10)+'0';
     rpm_data[2]=((rpm/10)%10)+'0';
     rpm_data[3]=(rpm%10)+'0';
     rpm_data[4]='\0';
     
     can_transmit(RPM_MSG_ID,rpm_data,4);
//     clcd_print("RPM: ",LINE1(0));
//     
//     clcd_putch((adc_reg_value/1000)+'0',LINE2(2));
//     clcd_putch((adc_reg_value/100%10)+'0',LINE2(3));
//     clcd_putch((adc_reg_value/10%10)+'0',LINE2(4));
//     clcd_putch((adc_reg_value%10)+'0',LINE2(5));
     
//      return adc_reg_value;
//     
//     
//     
}

//uint16_t get_engine_temp()
//{
//    //Implement the engine temperature function
//}

IndicatorStatus process_indicator(IndicatorStatus cur_ind_status)
{  
//    unsigned int delay=1000;
//   unsigned char key = read_digital_keypad(STATE_CHANGE);
  if(cur_ind_status==e_ind_left)
 {
      if(delay1-->5000)
      {
      
         LEFT_IND_ON();
         RIGHT_IND_OFF();
         
      
      }
      else if(delay1--<5000 && delay1>0)
      {
         LEFT_IND_OFF();
        
         
      }
      else
      {
          delay1=10000;
      }
  }
  if(cur_ind_status == e_ind_off)
  {
      RIGHT_IND_OFF();
      LEFT_IND_OFF();
      
      
   }
  if(cur_ind_status == e_ind_right)
  {
      if(delay2-->5000)
      {
        RIGHT_IND_ON();
        LEFT_IND_OFF();
      }
      else if(delay2--<5000 && delay2>0)
      {
          RIGHT_IND_OFF();
      }
      else
      {
          delay2=10000;
      
      }
      
  }

}
  
     