
///*
// * File:   main.c
// * Author: lavanya N U

#include <xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "digital_keypad.h"
#include "clcd.h"

volatile IndicatorStatus prev_ind_status,cur_ind_status;
unsigned int key;

uint8_t rpm_data[5];
uint8_t rpm_size=4;
uint8_t ind_size=1;

uint8_t  ind[2];

 


uint16_t rpm_id=RPM_MSG_ID;
uint16_t ind_id=INDICATOR_MSG_ID;



void init_config()
{
  init_adc();
  init_can();
    init_digital_keypad();
//   init_clcd();
    TRISB=0x08;
    PORTB=0x00;
}
int main()
{
   
    init_config();
    while(1)
    {
//      clcd_print("RPM: ",LINE1(0));
      get_rpm();
//      can_receive(&rpm_id,rpm_data,&rpm_size);
//      if(rpm_id==RPM_MSG_ID)
//      {
//          
//        clcd_print("RPM: ",LINE1(0));
//        clcd_print(rpm_data,LINE2(4));
//      }
       
        
       key = read_digital_keypad(STATE_CHANGE);
//       char ind[2];
       ind[1]='\0';
       if(key==SWITCH1)
       {
           cur_ind_status=e_ind_left;
             ind[0]='L';
            can_transmit(INDICATOR_MSG_ID,ind,2); 
             
       }
       else if(key==SWITCH2)
       {
           cur_ind_status=e_ind_off;
              ind[0]='O';
              can_transmit(INDICATOR_MSG_ID,ind,2);
       }
       else if(key==SWITCH3)
       {
           cur_ind_status=e_ind_right;
              ind[0]='R';
              can_transmit(INDICATOR_MSG_ID,ind,2);
       }
      
//      ind[1]='\0';
    
      
       process_indicator(cur_ind_status);
//       can_receive(&ind_id,rpm_data,&ind_size);
//       clcd_print(rpm_data,LINE2(5));
       
       
    }
}
