#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include<string.h>


 
extern uint8_t ev[9][3];
unsigned int index=0;
unsigned int speed;
extern uint8_t data[3];
unsigned int adc_reg_value;
extern uint8_t size;
extern uint8_t gr_size;
extern uint8_t gr_data[3];
//
void get_speed()
{
 
    adc_reg_value=read_adc(CHANNEL4);
    speed=(adc_reg_value*99.0)/1023;

//     clcd_putch((adc_reg_value/10)+48,LINE2(10));
//     clcd_putch((adc_reg_value%10)+48,LINE2(11));
       
    data[0]=(speed/10)+'0';
    data[1]=(speed % 10)+'0';
    data[2]='\0';
    
     can_transmit(SPEED_MSG_ID,data,size);
     for(int delay=1000;delay--;);
//    clcd_print("Speed: ",LINE1(10));
    // Implement the speed function
}

unsigned char get_gear_pos(unsigned int key)
{
    
//    unsigned char key;
//    
//    key=read_switches(STATE_CHANGE);
    
    if(key==MK_SW1)
    {
        if(index==8)
            index=1;
        else if(index<7)
            index++;
       

    }
    else if(key==MK_SW2)
    {
        if(index==8)
        index=1;
        else if(index>1)
            index--;

    }
    else if(key==MK_SW3)
    {
       
      
         index=8;
        
         
             
        
    }
    strcpy(gr_data,ev[index]);
    
    can_transmit(GEAR_MSG_ID,gr_data,gr_size);
//     for(int delay=1000;delay--;);
  
//    clcd_print("Gear: ",LINE1(0));
//    clcd_print(ev[index],LINE2(3));
  
}