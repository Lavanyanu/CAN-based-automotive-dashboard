/*
 * File:   main.c
 * Author: lavanya N U
 *
 * Created on 4 August, 2025, 2:33 PM
 */



    
#include<xc.h>
#include <string.h>
#include<stdlib.h>
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
//#include "uart.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "adc.h"

uint8_t ev[9][3]={"ON","GN","G1","G2","G3","G4","G5","GR","C_"};

uint8_t data[3];
unsigned int key;

 uint8_t size=2;
 
 uint8_t gr_size=2;
 uint8_t gr_data[3];
 
 uint16_t speed_id=SPEED_MSG_ID;
 uint16_t gear_id=GEAR_MSG_ID;
 
void init_config()
{
    init_clcd();
    init_adc();
    init_can();
    init_matrix_keypad();
   

}
int main()
{
     init_config();
//     unsigned int key;
//     clcd_print(gear[0],LINE2(14));
     
     while(1)
     {
       key=read_switches(STATE_CHANGE);  
      get_speed();
//      can_receive(&speed_id,data,&size);
//       if(speed_id==SPEED_MSG_ID)
//       {
////      clcd_print("Rx data:",LINE1(0));
//        clcd_print("Speed:",LINE1(0));
//        clcd_print(data,LINE2(4));
//       }
       
       get_gear_pos(key);
//       can_receive(&gear_id,gr_data,&gr_size);
//       if(gear_id==GEAR_MSG_ID)
//       {
//        clcd_print("Gear:",LINE1(3));
//        clcd_print(gr_data,LINE2(5));
//       }
     }
    //Call the functions
}